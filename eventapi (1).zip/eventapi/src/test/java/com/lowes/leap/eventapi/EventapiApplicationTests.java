package com.lowes.leap.eventapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
