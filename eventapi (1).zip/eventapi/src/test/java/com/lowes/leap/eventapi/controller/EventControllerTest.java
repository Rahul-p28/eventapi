package com.lowes.leap.eventapi.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.leap.eventapi.entity.Event;
import com.lowes.leap.eventapi.entity.Participant;
import com.lowes.leap.eventapi.service.EventService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.converter.json.Jackson2ObjectMapperBuilder.json;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EventController.class)
class EventControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private EventService eventService;

    @Test
    void getAllItems() throws Exception {
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        Participant participant2= Participant.builder()
                .participantId(2L)
                .participantFirstName("Nag")
                .participantLastName("Charan")
                .organization("hjhhjk")
                .designation("Manager")
                .emailAddress("example1.com")
                .build();
        List<Participant> participantList  = new ArrayList<>();
        participantList.add(participant1);
        participantList.add(participant2);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        Event event2= Event.builder()
                .eventId(2L)
                .eventName("Event2")
                .eventDescription("Description2")
                .status(Event.Status.OPEN)
                .eventStart(LocalDate.of(2023, 1, 3))
                .eventEnd(LocalDate.of(2023, 1, 4))
                .location(Event.Location.MOORESVILLE)
                .participants(participantList)
                .build();

        List<Event> eventList = new ArrayList<>();
        eventList.add(event1);
        eventList.add(event2);
        when(eventService.getAllItems()).thenReturn(eventList);
        mockMvc.perform(get("/v1/events")).andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }
    @Test
    void findEventByLocation() throws Exception{
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        Participant participant2= Participant.builder()
                .participantId(2L)
                .participantFirstName("Nag")
                .participantLastName("Charan")
                .organization("hjhhjk")
                .designation("Manager")
                .emailAddress("example1.com")
                .build();
        List<Participant> participantList  = new ArrayList<>();
        participantList.add(participant1);
        participantList.add(participant2);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        Event event2= Event.builder()
                .eventId(2L)
                .eventName("Event2")
                .eventDescription("Description2")
                .status(Event.Status.OPEN)
                .eventStart(LocalDate.of(2023, 1, 3))
                .eventEnd(LocalDate.of(2023, 1, 4))
                .location(Event.Location.MOORESVILLE)
                .participants(participantList)
                .build();

        List<Event> eventList = new ArrayList<>();
        eventList.add(event1);
        eventList.add(event2);
        when(eventService.findEventByLocation(Event.Location.BANGALORE)).thenReturn(eventList);
        mockMvc.perform(get("/v1/events/location/BANGALORE")).andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }
    @Test
     void getEventById() throws  Exception{
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        List<Participant> participantList  = new ArrayList<>();
        participantList.add(participant1);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();

        when(eventService.getEventById(1L)).thenReturn(Optional.ofNullable(event1));
        mockMvc.perform(get("/v1/events/participants/1")).andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName").value("Event1"));

    }
    @Test
    void deleteEvent() throws Exception{
        Long eventId = 1L;
        doNothing().when(eventService).deleteEventById(eventId);

        mockMvc.perform(delete("/v1/events/1"))
                .andExpect(status().isOk());
//                .andExpect(content().string("Event deleted successfully"));
    }


}