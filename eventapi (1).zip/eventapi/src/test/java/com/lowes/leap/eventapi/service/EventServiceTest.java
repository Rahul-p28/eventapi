package com.lowes.leap.eventapi.service;

import com.lowes.leap.eventapi.entity.Event;
import com.lowes.leap.eventapi.entity.Participant;
import com.lowes.leap.eventapi.repository.EventRepository;
import com.lowes.leap.eventapi.repository.ParticipantRepository;
import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.lowes.leap.eventapi.entity.Event.Location.BANGALORE;
import static com.lowes.leap.eventapi.entity.Event.Location.MOORESVILLE;
//import static com.lowes.leap.eventapi.entity.Event.Status.CREATED;
//import static com.lowes.leap.eventapi.entity.Event.Status.OPEN;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventServiceTest {

    @InjectMocks
    EventService eventService;
    @Mock
    EventRepository eventRepository;
    @Mock
    ParticipantRepository participantRepository;
    @Test
    void getAllEvents() {
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        Participant participant2= Participant.builder()
                .participantId(2L)
                .participantFirstName("Nag")
                .participantLastName("Charan")
                .organization("hjhhjk")
                .designation("Manager")
                .emailAddress("example1.com")
                .build();
        List<Participant>participantList  = new ArrayList<>();
        participantList.add(participant1);
        participantList.add(participant2);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        Event event2= Event.builder()
                .eventId(2L)
                .eventName("Event2")
                .eventDescription("Description2")
                .status(Event.Status.OPEN)
                .eventStart(LocalDate.of(2023, 1, 3))
                .eventEnd(LocalDate.of(2023, 1, 4))
                .location(Event.Location.MOORESVILLE)
                .participants(participantList)
                .build();

        List<Event> eventList = new ArrayList<>();
        eventList.add(event1);
        eventList.add(event2);

        Mockito.when(eventRepository.findAll()).thenReturn(eventList);
        List<Event> events =  eventService.getAllItems();
        assertEquals(2,events.size(),"Failed");
    }
    @Test
    void getEventById(){
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        Participant participant2= Participant.builder()
                .participantId(2L)
                .participantFirstName("Nag")
                .participantLastName("Charan")
                .organization("hjhhjk")
                .designation("Manager")
                .emailAddress("example1.com")
                .build();
        List<Participant>participantList  = new ArrayList<>();
        Event event = Event.builder().eventId(23L).eventName("ABCD").eventDescription("dcfgvbhjn").status(Event.Status.COMPLETED).eventStart(LocalDate.parse("2024-09-01")).eventEnd(LocalDate.parse("2024-09-09")).location(MOORESVILLE).participants(participantList).build();
        Mockito.when(eventRepository.findById(23L)).thenReturn(Optional.of(event));
        Optional<Event> event1  = eventService.getEventById(23L);
        assertEquals(23L,event1.get().getEventId());
    }
    @Test
    void findEventByLocation(){
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        Participant participant2= Participant.builder()
                .participantId(2L)
                .participantFirstName("Nag")
                .participantLastName("Charan")
                .organization("hjhhjk")
                .designation("Manager")
                .emailAddress("example1.com")
                .build();
        List<Participant>participantList  = new ArrayList<>();
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        Event event2= Event.builder()
                .eventId(2L)
                .eventName("Event2")
                .eventDescription("Description2")
                .status(Event.Status.OPEN)
                .eventStart(LocalDate.of(2023, 1, 3))
                .eventEnd(LocalDate.of(2023, 1, 4))
                .location(MOORESVILLE)
                .participants(participantList)
                .build();

        List<Event> eventList = new ArrayList<>();
        eventList.add(event1);
        eventList.add(event2);
        Mockito.when(eventRepository.findEventByLocation(BANGALORE)).thenReturn(eventList);
        List<Event> events = eventService.findEventByLocation(BANGALORE);
        assertEquals(2,events.size());
    }
    @Test
    void createEvent(){
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        List<Participant>participantList = new ArrayList<>();
        participantList.add(participant1);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        Mockito.when(eventRepository.save(event1)).thenReturn(event1);
        Event e  = eventService.createEvent(event1);
        assertEquals(event1,e);
    }
    @Test
    void deleteEventById(){//for else part we have handles this code in serive layer
        Participant participant1= Participant.builder()
                .participantId(1L)
                .participantFirstName("GGJBJKD")
                .participantLastName("Doe")
                .organization("jhdjkd")
                .designation("Tester")
                .emailAddress("example.com")
                .build();
        List<Participant>participantList = new ArrayList<>();
        participantList.add(participant1);
        Event event1= Event.builder()
                .eventId(1L)
                .eventName("Event1")
                .eventDescription("Description1")
                .status(Event.Status.CREATED)
                .eventStart(LocalDate.of(2023, 1, 1))
                .eventEnd(LocalDate.of(2023, 1, 2))
                .location(Event.Location.BANGALORE)
                .participants(participantList)
                .build();
        eventService.deleteEventById(1L);
        Mockito.verify(eventRepository,Mockito.times(0)).deleteById(1L);
    }
    @Test
    void DeleteEventById_WhenEventExists() {
        Long eventId = 1L;

        when(eventRepository.existsById(eventId)).thenReturn(true);

        eventService.deleteEventById(eventId);

        verify(eventRepository, times(1)).deleteById(eventId);
    }
    @Test
    void registerParticipant_eventNotFound() {
        Long eventId = 1L;
        Long participantId = 1L;

        Mockito.when(eventRepository.findById(eventId)).thenReturn(Optional.empty());

        ResponseEntity<String> response = eventService.registerParticipant(eventId, participantId);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }
    @Test
    void registerParticipant_participantNotFound() {
        Long eventId = 1L;
        Long participantId = 1L;

        Event event = new Event();
        Mockito.when(eventRepository.findById(eventId)).thenReturn(Optional.of(event));
        Mockito.when(participantRepository.findById(participantId)).thenReturn(Optional.empty());

        ResponseEntity<String> response = eventService.registerParticipant(eventId, participantId);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    @Test
    void registerParticipant_alreadyRegistered() {
        Long eventId = 1L;
        Long participantId = 1L;

        Event event = new Event();
        Participant participant = new Participant();
        event.getParticipants().add(participant);

        Mockito.when(eventRepository.findById(eventId)).thenReturn(Optional.of(event));
        Mockito.when(participantRepository.findById(participantId)).thenReturn(Optional.of(participant));

        ResponseEntity<String> response = eventService.registerParticipant(eventId, participantId);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    @Test
    void registerParticipant_success() {
        Long eventId = 1L;
        Long participantId = 1L;

        Event event = new Event();
        Participant participant = new Participant();

        Mockito.when(eventRepository.findById(eventId)).thenReturn(Optional.of(event));
        Mockito.when(participantRepository.findById(participantId)).thenReturn(Optional.of(participant));

        ResponseEntity<String> response = eventService.registerParticipant(eventId, participantId);

        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}