package com.lowes.leap.eventapi.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "participant")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Participant {
    @Id
    Long participantId;
    String participantFirstName ;
    String participantLastName;
    String organization ;
    String designation;
    String emailAddress;
    @ManyToMany(mappedBy = "participants",fetch = FetchType.LAZY)
    @JsonBackReference
    private List<Event>events = new ArrayList<>();
}
