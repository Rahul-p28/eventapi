package com.lowes.leap.eventapi.controller;

import com.lowes.leap.eventapi.entity.Event;
import com.lowes.leap.eventapi.entity.Participant;
import com.lowes.leap.eventapi.service.EventService;
import com.lowes.leap.eventapi.service.ParticipantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class ParticipantController {
    @Autowired
    EventService eventService;
    @Autowired
    ParticipantService participantServicer;
    @PostMapping("/v1/events/{eventId}/participants/{participantId}")
    public ResponseEntity<String> registerParticipant(
            @PathVariable Long eventId,
            @PathVariable Long participantId) {
        return eventService.registerParticipant(eventId, participantId);
    }
    @GetMapping("/v1/participant")
    public List<Participant> getAllItems(){
        return participantServicer.getAllItems();
    }
    @PostMapping("v1/participant")
    public ResponseEntity<Participant> createparticipant(@RequestBody Participant participant){
        Participant p = participantServicer.createparticipant(participant);
        return new ResponseEntity<>(p, HttpStatus.CREATED);
    }

}
