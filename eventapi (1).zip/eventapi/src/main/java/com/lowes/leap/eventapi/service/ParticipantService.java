package com.lowes.leap.eventapi.service;

import com.lowes.leap.eventapi.entity.Participant;
import com.lowes.leap.eventapi.repository.ParticipantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParticipantService {
    @Autowired
    private ParticipantRepository participantRepository;

    public List<Participant> getAllItems() {
        return participantRepository.findAll();
    }

    public Participant createparticipant(Participant participant) {
        return participantRepository.save(participant);
    }
}
