package com.lowes.leap.eventapi.service;

import com.lowes.leap.eventapi.entity.Event;
import com.lowes.leap.eventapi.entity.Participant;
import com.lowes.leap.eventapi.repository.EventRepository;

import com.lowes.leap.eventapi.repository.ParticipantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class EventService {
    @Autowired
    EventRepository eventRepository;
    @Autowired
    ParticipantRepository participantRepository;

    public List<Event> getAllItems() {
        return eventRepository.findAll();
    }

    public Event createEvent(Event event) {
        return eventRepository.save(event);
    }


    public List<Event> findEventByLocation(Event.Location location) {

        return eventRepository.findEventByLocation(location);
    }

    public void deleteEventById(Long id) {
        if (eventRepository.existsById(id)) {
            eventRepository.deleteById(id);
        } else {
            new  ResponseEntity<>("Event not found with id: " + id, HttpStatus.NOT_FOUND);
        }
    }



    public Optional<Event> getEventById(Long eventId) {

            return eventRepository.findById(eventId);
    }


    public ResponseEntity<String> registerParticipant(Long eventId, Long participantId) {

            Optional<Event> eventOpt = eventRepository.findById(eventId);
            Optional<Participant> participantOpt = participantRepository.findById(participantId);

            if (eventOpt.isEmpty()) {
                return ResponseEntity.badRequest().body("Event not found with ID: " + eventId);
            }

            if (participantOpt.isEmpty()) {
                return ResponseEntity.badRequest().body("Participant not found with ID: " + participantId);
            }

            Event event = eventOpt.get();
            Participant participant = participantOpt.get();

            // Check if participant is already registered
            if (event.getParticipants().contains(participant)) {
                return ResponseEntity.badRequest().body("Participant is already registered for this event.");
            }

            // Add participant to event
            event.getParticipants().add(participant);
            eventRepository.save(event);

            return ResponseEntity.ok("Participant registered successfully.");

    }
}
