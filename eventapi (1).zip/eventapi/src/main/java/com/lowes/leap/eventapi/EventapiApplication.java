package com.lowes.leap.eventapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventapiApplication.class, args);
	}

}
