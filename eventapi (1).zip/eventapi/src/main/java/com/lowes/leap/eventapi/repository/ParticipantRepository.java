package com.lowes.leap.eventapi.repository;

import com.lowes.leap.eventapi.entity.Participant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipantRepository extends JpaRepository<Participant,Long> {
}
