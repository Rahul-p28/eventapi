package com.lowes.leap.eventapi.controller;

import com.lowes.leap.eventapi.entity.Event;
import com.lowes.leap.eventapi.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@CrossOrigin
@RestController
public class EventController {
    @Autowired
    EventService eventService;
    @GetMapping("/v1/events")
    public List<Event> getAllItems(){
        return eventService.getAllItems();
    }
    @PostMapping("/v1/events")
    public ResponseEntity<Event> createItem(@RequestBody Event event) {
        Event response = eventService.createEvent(event);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    @GetMapping("/v1/events/location/{location}")
    public ResponseEntity<List<Event>> findEventByLocation(@PathVariable Event.Location location){
        List<Event> E = eventService.findEventByLocation(location);
        return ResponseEntity.ok(E);
    }
    @DeleteMapping("/v1/events/{id}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Long id) {
        eventService.deleteEventById(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/v1/events/participants/{eventId}")
    public Optional<Event> getEventById(@PathVariable Long eventId) {
        return eventService.getEventById(eventId);
    }
    @PutMapping("/v1/event/{id}")
    public ResponseEntity<Event> updateEvent(@PathVariable Long id, @RequestBody Event eventDetails) {
        Optional<Event> optionalEvent = eventService.getEventById(id);
        if (optionalEvent.isPresent()) {
            Event event = optionalEvent.get();
            event.setEventName(eventDetails.getEventName());
            event.setEventDescription(eventDetails.getEventDescription());
            event.setStatus(eventDetails.getStatus());
            event.setEventStart(eventDetails.getEventStart());
            event.setEventEnd(eventDetails.getEventEnd());
            event.setLocation(eventDetails.getLocation());
            Event updatedEvent = eventService.createEvent(event);
            return ResponseEntity.ok(updatedEvent);
        } else {
            return ResponseEntity.notFound().build();
        }
    }




}
