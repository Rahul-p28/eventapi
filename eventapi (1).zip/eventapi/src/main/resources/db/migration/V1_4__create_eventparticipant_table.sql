CREATE TABLE  eventparticipant(
   event_id BIGINT NOT NULL,
   participant_id BIGINT NOT NULL,
   CONSTRAINT event_id_fkey FOREIGN KEY (event_id)
   REFERENCES event(event_id),
   CONSTRAINT participant_id_fkey FOREIGN KEY (participant_id)
   REFERENCES participant(participant_id)
);