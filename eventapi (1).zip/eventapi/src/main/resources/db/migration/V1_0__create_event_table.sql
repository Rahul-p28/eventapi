CREATE TABLE event
(
    event_id BIGINT NOT NULL,
    event_name text NOT NULL,
    event_description text NOT NULL,
    status text NOT NULL CHECK (status IN ('CREATED','OPEN', 'INPROGRESS', 'COMPLETED')),
    event_start date NOT NULL,
    event_end date  NOT NULL,
    location text NOT NULL ,
    CONSTRAINT event_id_pkey PRIMARY KEY (event_id)
);
