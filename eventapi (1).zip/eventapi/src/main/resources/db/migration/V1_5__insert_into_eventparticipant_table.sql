insert into eventparticipant(event_id,participant_id) VALUES (1,1);
insert into eventparticipant(event_id,participant_id) VALUES (1,2);
insert into eventparticipant(event_id,participant_id) VALUES (1,3);
insert into eventparticipant(event_id,participant_id) VALUES (2,2);
insert into eventparticipant(event_id,participant_id) VALUES (2,1);
