CREATE TABLE participant
(
    participant_id BIGINT NOT NULL,
    participant_first_name text NOT NULL,
    participant_last_name TEXT NOT NULL,
    organization text NOT NULL,
    designation text NOT NULL,
    email_address  text NOT NULL,
    CONSTRAINT participant_id_pkey PRIMARY KEY (participant_id)
);
