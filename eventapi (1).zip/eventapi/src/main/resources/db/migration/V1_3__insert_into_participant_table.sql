INSERT INTO participant(participant_id,participant_first_name, participant_last_name, organization, designation, email_address) VALUES (001,'Raju', 'Bhardwaj', 'CREATED', 'ABC', 'Finance head');
INSERT INTO participant(participant_id,participant_first_name, participant_last_name, organization, designation, email_address) VALUES (002,'Riya', 'NA', 'CREATED', 'ABC', 'Hr');
INSERT INTO participant(participant_id,participant_first_name, participant_last_name, organization, designation, email_address) VALUES (003,'bnm', 'vcdx', 'CREATED', 'ABC', 'SDE');
